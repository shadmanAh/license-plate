var app = angular.module('demo', []);
var controllers = {};
var alphabet = ['الف', 'ب', 'پ', 'ت','ث','ج','ح','خ','د','ذ','ر','ز','ژ','س','ش','ص','ض','ط','ظ','ع','غ','ف',
'ق','ک','گ','ل','م','ن','و','ه','ی','D','S'];
var divToHide = document.getElementById('divToHide');



app.directive('searchList', function() {
    return {
        scope: {
            searchModel: '=model'
        },
        link: function(scope, element, attrs) {
            element.on('click', attrs.searchList, function() {
                scope.searchModel = $(this).text();
                scope.$apply();
            });
        }
    };
});

controllers.MainController = function($scope) {
    $scope.setTerm = function(letter) {
        $scope.search = letter;
    };
    $scope.flag = 'none';

    $scope.alphabet = {
      letter: alphabet
    }

    $scope.show = function(){
      $scope.flag = 'block';
    }

    document.onclick = function(e){
      if(e.target.id !== 'divToHide'){
        //element clicked wasn't the div; hide the div
        $scope.flag = 'none';
      }
    };
  
  $scope.startsWith = function (actual, expected) {
    var lowerStr = (actual + "").toLowerCase();
    return lowerStr.indexOf(expected.toLowerCase()) === 0;
  }
};


app.controller(controllers);